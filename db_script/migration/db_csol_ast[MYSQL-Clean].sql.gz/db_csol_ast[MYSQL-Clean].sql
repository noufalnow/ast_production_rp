-- Adminer 4.8.1 MySQL 8.0.40-0ubuntu0.22.04.1 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `cnfg_acl_actions`;
CREATE TABLE `cnfg_acl_actions` (
  `action_id` bigint NOT NULL,
  `action_controller_id` bigint NOT NULL,
  `action_name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `action_label` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `action_desc` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `action_resource` smallint DEFAULT NULL,
  `action_type` smallint DEFAULT NULL,
  `u_created` bigint DEFAULT NULL,
  `u_modified` bigint DEFAULT NULL,
  `u_deleted` bigint DEFAULT NULL,
  `t_created` datetime DEFAULT NULL,
  `t_modified` datetime DEFAULT NULL,
  `t_deleted` datetime DEFAULT NULL,
  `deleted` smallint NOT NULL DEFAULT '0',
  `is_synched` smallint DEFAULT '1',
  PRIMARY KEY (`action_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


DROP TABLE IF EXISTS `cnfg_acl_actions_access`;
CREATE TABLE `cnfg_acl_actions_access` (
  `aacc_id` bigint NOT NULL,
  `aacc_action_id` bigint NOT NULL,
  `aacc_role_id` bigint NOT NULL,
  `aacc_role_type` smallint NOT NULL,
  `aacc_access_status` smallint NOT NULL DEFAULT '1',
  `u_created` bigint DEFAULT NULL,
  `u_modified` bigint DEFAULT NULL,
  `u_deleted` bigint DEFAULT NULL,
  `t_created` datetime DEFAULT NULL,
  `t_modified` datetime DEFAULT NULL,
  `t_deleted` datetime DEFAULT NULL,
  `deleted` smallint NOT NULL DEFAULT '0',
  `is_synched` smallint DEFAULT '1',
  PRIMARY KEY (`aacc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


DROP TABLE IF EXISTS `cnfg_acl_controllers`;
CREATE TABLE `cnfg_acl_controllers` (
  `controller_id` bigint NOT NULL,
  `controller_module_id` bigint NOT NULL,
  `controller_name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `controller_label` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `controller_desc` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `u_created` bigint DEFAULT NULL,
  `u_modified` bigint DEFAULT NULL,
  `u_deleted` bigint DEFAULT NULL,
  `t_created` datetime DEFAULT NULL,
  `t_modified` datetime DEFAULT NULL,
  `t_deleted` datetime DEFAULT NULL,
  `deleted` smallint NOT NULL DEFAULT '0',
  `is_synched` smallint DEFAULT '1',
  PRIMARY KEY (`controller_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


DROP TABLE IF EXISTS `cnfg_acl_controllers_access`;
CREATE TABLE `cnfg_acl_controllers_access` (
  `cacc_id` bigint NOT NULL,
  `cacc_controller_id` bigint NOT NULL,
  `cacc_role_id` bigint NOT NULL,
  `cacc_role_type` smallint NOT NULL,
  `cacc_create_status` smallint NOT NULL DEFAULT '1',
  `cacc_update_status` smallint NOT NULL DEFAULT '1',
  `cacc_view_status` smallint NOT NULL DEFAULT '1',
  `cacc_delete_status` smallint NOT NULL DEFAULT '1',
  `u_created` bigint DEFAULT NULL,
  `u_modified` bigint DEFAULT NULL,
  `u_deleted` bigint DEFAULT NULL,
  `t_created` datetime DEFAULT NULL,
  `t_modified` datetime DEFAULT NULL,
  `t_deleted` datetime DEFAULT NULL,
  `deleted` smallint NOT NULL DEFAULT '0',
  `is_synched` smallint DEFAULT '1',
  PRIMARY KEY (`cacc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


DROP TABLE IF EXISTS `cnfg_acl_modules`;
CREATE TABLE `cnfg_acl_modules` (
  `module_id` bigint NOT NULL,
  `module_name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `module_label` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `module_desc` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `u_created` bigint DEFAULT NULL,
  `u_modified` bigint DEFAULT NULL,
  `u_deleted` bigint DEFAULT NULL,
  `t_created` datetime DEFAULT NULL,
  `t_modified` datetime DEFAULT NULL,
  `t_deleted` datetime DEFAULT NULL,
  `deleted` smallint NOT NULL DEFAULT '0',
  `is_synched` smallint DEFAULT '1',
  PRIMARY KEY (`module_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


DROP TABLE IF EXISTS `cnfg_acl_modules_access`;
CREATE TABLE `cnfg_acl_modules_access` (
  `macc_id` bigint NOT NULL,
  `macc_module_id` bigint NOT NULL,
  `macc_role_id` bigint NOT NULL,
  `macc_role_type` smallint NOT NULL,
  `macc_create_status` smallint NOT NULL DEFAULT '1',
  `macc_update_status` smallint NOT NULL DEFAULT '1',
  `macc_view_status` smallint NOT NULL DEFAULT '1',
  `macc_delete_status` smallint NOT NULL DEFAULT '1',
  `u_created` bigint DEFAULT NULL,
  `u_modified` bigint DEFAULT NULL,
  `u_deleted` bigint DEFAULT NULL,
  `t_created` datetime DEFAULT NULL,
  `t_modified` datetime DEFAULT NULL,
  `t_deleted` datetime DEFAULT NULL,
  `deleted` smallint NOT NULL DEFAULT '0',
  `is_synched` smallint DEFAULT '1',
  PRIMARY KEY (`macc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


DROP TABLE IF EXISTS `core_action_log`;
CREATE TABLE `core_action_log` (
  `alog_id` bigint NOT NULL,
  `alog_user_log_id` bigint DEFAULT NULL,
  `alog_module` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `alog_action` smallint DEFAULT NULL,
  `alog_table` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `alog_ref` bigint DEFAULT NULL,
  `alog_data` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `u_created` bigint DEFAULT NULL,
  `u_modified` bigint DEFAULT NULL,
  `u_deleted` bigint DEFAULT NULL,
  `t_created` timestamp NULL DEFAULT NULL,
  `t_modified` timestamp NULL DEFAULT NULL,
  `t_deleted` timestamp NULL DEFAULT NULL,
  `deleted` smallint DEFAULT '0',
  PRIMARY KEY (`alog_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


DROP TABLE IF EXISTS `core_bank_account`;
CREATE TABLE `core_bank_account` (
  `acnt_id` bigint NOT NULL,
  `acnt_company` smallint DEFAULT NULL,
  `acnt_type` smallint NOT NULL DEFAULT '1',
  `acnt_bank` smallint NOT NULL,
  `acnt_branch` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `acnt_name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `acnt_number` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `acnt_remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `acnt_disp_name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `u_created` bigint DEFAULT NULL,
  `u_modified` bigint DEFAULT NULL,
  `u_deleted` bigint DEFAULT NULL,
  `t_created` datetime DEFAULT NULL,
  `t_modified` datetime DEFAULT NULL,
  `t_deleted` datetime DEFAULT NULL,
  `deleted` smallint NOT NULL DEFAULT '0',
  `is_synched` smallint DEFAULT '1',
  PRIMARY KEY (`acnt_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


DROP TABLE IF EXISTS `core_category`;
CREATE TABLE `core_category` (
  `cat_id` bigint NOT NULL,
  `cat_type` smallint NOT NULL,
  `cat_name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `cat_remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `cat_parent` bigint DEFAULT NULL,
  `u_created` bigint DEFAULT NULL,
  `u_modified` bigint DEFAULT NULL,
  `u_deleted` bigint DEFAULT NULL,
  `t_created` datetime DEFAULT NULL,
  `t_modified` datetime DEFAULT NULL,
  `t_deleted` datetime DEFAULT NULL,
  `deleted` smallint NOT NULL DEFAULT '0',
  `is_synched` smallint DEFAULT '1',
  PRIMARY KEY (`cat_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


DROP TABLE IF EXISTS `core_comp_department`;
CREATE TABLE `core_comp_department` (
  `cmpdept_id` bigint NOT NULL,
  `cmpdept_dept_id` bigint NOT NULL,
  `cmpdept_comp_id` bigint NOT NULL,
  `cmpdept_contact_person` bigint DEFAULT NULL,
  `u_created` bigint DEFAULT NULL,
  `u_modified` bigint DEFAULT NULL,
  `u_deleted` bigint DEFAULT NULL,
  `t_created` datetime DEFAULT NULL,
  `t_modified` datetime DEFAULT NULL,
  `t_deleted` datetime DEFAULT NULL,
  `deleted` smallint NOT NULL DEFAULT '0',
  `is_synched` smallint DEFAULT '1',
  PRIMARY KEY (`cmpdept_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


DROP TABLE IF EXISTS `core_company`;
CREATE TABLE `core_company` (
  `comp_id` bigint NOT NULL,
  `comp_name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `comp_disp_name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `comp_reg_no` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `comp_contact_person` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `u_created` bigint DEFAULT NULL,
  `u_modified` bigint DEFAULT NULL,
  `u_deleted` bigint DEFAULT NULL,
  `t_created` datetime DEFAULT NULL,
  `t_modified` datetime DEFAULT NULL,
  `t_deleted` datetime DEFAULT NULL,
  `deleted` smallint DEFAULT '0',
  `is_synched` smallint DEFAULT '1',
  PRIMARY KEY (`comp_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


DROP TABLE IF EXISTS `core_department`;
CREATE TABLE `core_department` (
  `dept_id` bigint NOT NULL,
  `dept_name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `dept_contact_person` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `u_created` bigint DEFAULT NULL,
  `u_modified` bigint DEFAULT NULL,
  `u_deleted` bigint DEFAULT NULL,
  `t_created` datetime DEFAULT NULL,
  `t_modified` datetime DEFAULT NULL,
  `t_deleted` datetime DEFAULT NULL,
  `deleted` smallint NOT NULL DEFAULT '0',
  `is_synched` smallint DEFAULT '1',
  PRIMARY KEY (`dept_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


DROP TABLE IF EXISTS `core_designation`;
CREATE TABLE `core_designation` (
  `desig_id` bigint NOT NULL,
  `desig_name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `u_created` bigint DEFAULT NULL,
  `u_modified` bigint DEFAULT NULL,
  `u_deleted` bigint DEFAULT NULL,
  `t_created` datetime DEFAULT NULL,
  `t_modified` datetime DEFAULT NULL,
  `t_deleted` datetime DEFAULT NULL,
  `deleted` smallint NOT NULL DEFAULT '0',
  `is_synched` smallint DEFAULT '1',
  PRIMARY KEY (`desig_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


DROP TABLE IF EXISTS `core_files`;
CREATE TABLE `core_files` (
  `file_id` bigint NOT NULL,
  `file_type` smallint NOT NULL,
  `file_ref_id` bigint NOT NULL,
  `file_actual_name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `file_exten` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `file_size` bigint DEFAULT NULL,
  `u_created` bigint DEFAULT NULL,
  `u_modified` bigint DEFAULT NULL,
  `u_deleted` bigint DEFAULT NULL,
  `t_created` datetime DEFAULT NULL,
  `t_modified` datetime DEFAULT NULL,
  `t_deleted` datetime DEFAULT NULL,
  `deleted` smallint NOT NULL DEFAULT '0',
  `is_synched` smallint DEFAULT '1',
  PRIMARY KEY (`file_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


DROP TABLE IF EXISTS `core_login_log`;
CREATE TABLE `core_login_log` (
  `log_id` bigint NOT NULL,
  `log_remote_addr` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `log_http_user_agent` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `log_remote_port` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `u_created` bigint DEFAULT NULL,
  `u_modified` bigint DEFAULT NULL,
  `u_deleted` bigint DEFAULT NULL,
  `t_created` datetime DEFAULT NULL,
  `t_modified` datetime DEFAULT NULL,
  `t_deleted` datetime DEFAULT NULL,
  `deleted` smallint DEFAULT '0',
  `is_synched` smallint DEFAULT '1',
  PRIMARY KEY (`log_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


DROP TABLE IF EXISTS `core_updates`;
CREATE TABLE `core_updates` (
  `upd_id` bigint NOT NULL,
  `upd_type` smallint NOT NULL,
  `upd_type_refid` bigint NOT NULL,
  `upd_reported` bigint NOT NULL,
  `upd_dttime` timestamp NULL DEFAULT NULL,
  `upd_enddttime` timestamp NULL DEFAULT NULL,
  `upd_priority` smallint NOT NULL,
  `upd_note` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `upd_title` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `upd_deleted` smallint NOT NULL DEFAULT '0',
  `u_created` bigint DEFAULT NULL,
  `u_modified` bigint DEFAULT NULL,
  `u_deleted` bigint DEFAULT NULL,
  `t_created` datetime DEFAULT NULL,
  `t_modified` datetime DEFAULT NULL,
  `t_deleted` datetime DEFAULT NULL,
  `deleted` smallint NOT NULL DEFAULT '0',
  `upd_status` smallint DEFAULT '1',
  `upd_close_date` timestamp NULL DEFAULT NULL,
  `upd_close_by` bigint DEFAULT NULL,
  `upd_close_note` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `upd_assign` bigint DEFAULT NULL,
  `upd_remainder` smallint DEFAULT NULL,
  `is_synched` smallint DEFAULT '1',
  PRIMARY KEY (`upd_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


DROP TABLE IF EXISTS `core_users`;
CREATE TABLE `core_users` (
  `user_id` bigint NOT NULL,
  `user_fname` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `user_lname` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `user_uname` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `user_status` smallint DEFAULT '1',
  `user_password` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `user_desig` bigint DEFAULT NULL,
  `user_dept` bigint DEFAULT NULL,
  `u_created` bigint DEFAULT NULL,
  `u_modified` bigint DEFAULT NULL,
  `u_deleted` bigint DEFAULT NULL,
  `t_created` datetime DEFAULT NULL,
  `t_modified` datetime DEFAULT NULL,
  `t_deleted` datetime DEFAULT NULL,
  `deleted` smallint DEFAULT '0',
  `user_emp_id` bigint DEFAULT NULL,
  `user_email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `is_synched` smallint DEFAULT '1',
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


DROP TABLE IF EXISTS `mis_bill`;
CREATE TABLE `mis_bill` (
  `bill_id` bigint NOT NULL,
  `bill_company` bigint DEFAULT NULL,
  `bill_refno` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `bill_customer_id` bigint NOT NULL,
  `bill_mode` smallint NOT NULL,
  `bill_remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `bill_total` decimal(13,3) NOT NULL,
  `u_created` bigint DEFAULT NULL,
  `u_modified` bigint DEFAULT NULL,
  `u_deleted` bigint DEFAULT NULL,
  `t_created` datetime DEFAULT NULL,
  `t_modified` datetime DEFAULT NULL,
  `t_deleted` datetime DEFAULT NULL,
  `deleted` smallint NOT NULL DEFAULT '0',
  `bill_date` date DEFAULT NULL,
  `bill_month` date DEFAULT NULL,
  `bill_rev_date` date DEFAULT NULL,
  `bill_file_no` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `bill_app_status` smallint DEFAULT NULL,
  `bill_app_date` timestamp NULL DEFAULT NULL,
  `bill_app_note` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `bill_pstatus` bigint DEFAULT NULL,
  `bill_credit_amt` decimal(13,3) DEFAULT NULL,
  `bill_oribill_amt` decimal(13,3) DEFAULT NULL,
  `bill_book_no` bigint DEFAULT NULL,
  `bill_cancellation_status` smallint NOT NULL DEFAULT '0',
  `bill_eedit_note` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `bill_wo` bigint DEFAULT NULL,
  `bill_wo_note` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `bill_location` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `is_synched` smallint DEFAULT '1',
  PRIMARY KEY (`bill_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


DROP TABLE IF EXISTS `mis_bill_det`;
CREATE TABLE `mis_bill_det` (
  `bdet_id` bigint NOT NULL,
  `bdet_bill_id` bigint DEFAULT NULL,
  `bdet_item` bigint NOT NULL,
  `bdet_qty` decimal(9,3) NOT NULL,
  `bdet_amt` decimal(13,3) NOT NULL,
  `bdet_remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `u_created` bigint DEFAULT NULL,
  `u_modified` bigint DEFAULT NULL,
  `u_deleted` bigint DEFAULT NULL,
  `t_created` datetime DEFAULT NULL,
  `t_modified` datetime DEFAULT NULL,
  `t_deleted` datetime DEFAULT NULL,
  `deleted` smallint NOT NULL DEFAULT '0',
  `bdet_update_sts` smallint NOT NULL DEFAULT '0',
  `is_synched` smallint DEFAULT '1',
  PRIMARY KEY (`bdet_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


DROP TABLE IF EXISTS `mis_building`;
CREATE TABLE `mis_building` (
  `bld_id` bigint NOT NULL,
  `bld_name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `bld_no` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `bld_area` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `bld_block_no` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `bld_plot_no` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `bld_way` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `bld_street` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `bld_block` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `u_created` bigint DEFAULT NULL,
  `u_modified` bigint DEFAULT NULL,
  `u_deleted` bigint DEFAULT NULL,
  `t_created` datetime DEFAULT NULL,
  `t_modified` datetime DEFAULT NULL,
  `t_deleted` datetime DEFAULT NULL,
  `deleted` smallint NOT NULL DEFAULT '0',
  `bld_comp` smallint DEFAULT NULL,
  `is_synched` smallint DEFAULT '1',
  PRIMARY KEY (`bld_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


DROP TABLE IF EXISTS `mis_call_log`;
CREATE TABLE `mis_call_log` (
  `clog_id` bigint NOT NULL,
  `clog_type` smallint DEFAULT '1',
  `clog_phone_no` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `clog_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `clog_email` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `clog_date` date NOT NULL,
  `clog_time` time DEFAULT NULL,
  `clog_emp` bigint DEFAULT NULL,
  `clog_log` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `clog_fup_json` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `clog_sts_for` smallint DEFAULT '1',
  `clog_sts` smallint DEFAULT '1',
  `u_created` bigint DEFAULT NULL,
  `u_modified` bigint DEFAULT NULL,
  `u_deleted` bigint DEFAULT NULL,
  `t_created` datetime DEFAULT NULL,
  `t_modified` datetime DEFAULT NULL,
  `t_deleted` datetime DEFAULT NULL,
  `deleted` smallint NOT NULL DEFAULT '0',
  `clog_sts_cur` smallint DEFAULT NULL,
  `is_synched` smallint DEFAULT '1',
  PRIMARY KEY (`clog_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


DROP TABLE IF EXISTS `mis_call_log_follow`;
CREATE TABLE `mis_call_log_follow` (
  `cflo_id` bigint NOT NULL,
  `cflo_clog_id` bigint DEFAULT NULL,
  `cflo_log` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `cflo_date` date NOT NULL,
  `cflo_time` time DEFAULT NULL,
  `cflo_emp` bigint DEFAULT NULL,
  `cflo_prv_sts` smallint DEFAULT '1',
  `cflo_sts` smallint DEFAULT '1',
  `u_created` bigint DEFAULT NULL,
  `u_modified` bigint DEFAULT NULL,
  `u_deleted` bigint DEFAULT NULL,
  `t_created` datetime DEFAULT NULL,
  `t_modified` datetime DEFAULT NULL,
  `t_deleted` datetime DEFAULT NULL,
  `deleted` smallint NOT NULL DEFAULT '0',
  `is_synched` smallint DEFAULT '1',
  PRIMARY KEY (`cflo_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


DROP TABLE IF EXISTS `mis_cash_book`;
CREATE TABLE `mis_cash_book` (
  `cb_id` bigint NOT NULL,
  `cb_type` smallint NOT NULL,
  `cb_type_ref` bigint NOT NULL,
  `cb_exp_id` bigint DEFAULT NULL,
  `cb_debit` decimal(13,3) DEFAULT NULL,
  `cb_credit` decimal(13,3) DEFAULT NULL,
  `cb_date` date NOT NULL,
  `cb_debit_note` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `cb_status` smallint DEFAULT NULL,
  `u_created` bigint DEFAULT NULL,
  `u_modified` bigint DEFAULT NULL,
  `u_deleted` bigint DEFAULT NULL,
  `t_created` datetime DEFAULT NULL,
  `t_modified` datetime DEFAULT NULL,
  `t_deleted` datetime DEFAULT NULL,
  `deleted` smallint NOT NULL DEFAULT '0',
  `cb_src` smallint DEFAULT NULL,
  `cb_src_inc` bigint DEFAULT NULL,
  `cb_src_det` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `cb_exp_type` smallint DEFAULT '1',
  `is_synched` smallint DEFAULT '1',
  PRIMARY KEY (`cb_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


DROP TABLE IF EXISTS `mis_cash_demand`;
CREATE TABLE `mis_cash_demand` (
  `cdmd_id` bigint NOT NULL,
  `cdmd_type` smallint NOT NULL DEFAULT '1',
  `cdmd_ref_id` bigint NOT NULL,
  `cdmd_oth_id` bigint DEFAULT NULL,
  `cdmd_narration` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `cdmd_note` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `cdmd_mode` smallint NOT NULL,
  `cdmd_total` decimal(13,3) NOT NULL,
  `cdmd_date` date NOT NULL,
  `cdmd_month` date NOT NULL,
  `cdmd_app_status` smallint DEFAULT NULL,
  `cdmd_app_date` timestamp NULL DEFAULT NULL,
  `cdmd_app_note` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `cdmd_pstatus` smallint NOT NULL DEFAULT '2',
  `cdmd_credit_amt` decimal(13,3) DEFAULT NULL,
  `cdmd_orig_amt` decimal(13,3) DEFAULT NULL,
  `cdmd_cancellation_status` smallint NOT NULL DEFAULT '0',
  `u_created` bigint DEFAULT NULL,
  `u_modified` bigint DEFAULT NULL,
  `u_deleted` bigint DEFAULT NULL,
  `t_created` datetime DEFAULT NULL,
  `t_modified` datetime DEFAULT NULL,
  `t_deleted` datetime DEFAULT NULL,
  `deleted` smallint NOT NULL DEFAULT '0',
  `is_synched` smallint DEFAULT '1',
  PRIMARY KEY (`cdmd_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


DROP TABLE IF EXISTS `mis_cash_flow`;
CREATE TABLE `mis_cash_flow` (
  `cf_id` bigint NOT NULL,
  `cf_cb_id` bigint NOT NULL,
  `cf_assigned` bigint DEFAULT NULL,
  `cf_dttime` timestamp NULL DEFAULT NULL,
  `cf_amount` decimal(13,3) NOT NULL,
  `cf_note` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `cf_note_ar` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `cf_status` smallint NOT NULL DEFAULT '1',
  `u_created` bigint DEFAULT NULL,
  `u_modified` bigint DEFAULT NULL,
  `u_deleted` bigint DEFAULT NULL,
  `t_created` datetime DEFAULT NULL,
  `t_modified` datetime DEFAULT NULL,
  `t_deleted` datetime DEFAULT NULL,
  `deleted` smallint NOT NULL DEFAULT '0',
  `cf_approve` smallint DEFAULT '1',
  `cf_approve_time` timestamp NULL DEFAULT NULL,
  `cf_approve_by` bigint DEFAULT NULL,
  `is_synched` smallint DEFAULT '1',
  PRIMARY KEY (`cf_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


DROP TABLE IF EXISTS `mis_collection`;
CREATE TABLE `mis_collection` (
  `coll_id` bigint NOT NULL,
  `coll_cust` bigint NOT NULL,
  `coll_amount` decimal(13,3) NOT NULL,
  `coll_coll_mode` smallint NOT NULL DEFAULT '1',
  `coll_chqno` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `coll_remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `coll_paydate` date NOT NULL,
  `coll_refno` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `coll_status` smallint NOT NULL DEFAULT '1',
  `coll_file_no` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `coll_app_date` date DEFAULT NULL,
  `coll_app_by` bigint DEFAULT NULL,
  `coll_app_note` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `coll_app_status` smallint DEFAULT '0',
  `u_created` bigint DEFAULT NULL,
  `u_modified` bigint DEFAULT NULL,
  `u_deleted` bigint DEFAULT NULL,
  `t_created` datetime DEFAULT NULL,
  `t_modified` datetime DEFAULT NULL,
  `t_deleted` datetime DEFAULT NULL,
  `deleted` smallint NOT NULL DEFAULT '0',
  `coll_src_type` bigint NOT NULL DEFAULT '1',
  `is_synched` smallint DEFAULT '1',
  PRIMARY KEY (`coll_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


DROP TABLE IF EXISTS `mis_collection_det`;
CREATE TABLE `mis_collection_det` (
  `cdet_id` bigint NOT NULL,
  `cdet_coll_id` bigint DEFAULT NULL,
  `cdet_bill_id` bigint DEFAULT NULL,
  `cdet_amt_topay` decimal(13,3) NOT NULL,
  `cdet_amt_paid` decimal(13,3) NOT NULL,
  `cdet_amt_dis` decimal(13,3) DEFAULT NULL,
  `cdet_amt_bal` decimal(13,3) DEFAULT NULL,
  `cdet_status` smallint DEFAULT '1',
  `u_created` bigint DEFAULT NULL,
  `u_modified` bigint DEFAULT NULL,
  `u_deleted` bigint DEFAULT NULL,
  `t_created` datetime DEFAULT NULL,
  `t_modified` datetime DEFAULT NULL,
  `t_deleted` datetime DEFAULT NULL,
  `deleted` smallint NOT NULL DEFAULT '0',
  `cdet_src_type` bigint NOT NULL DEFAULT '1',
  `is_synched` smallint DEFAULT '1',
  PRIMARY KEY (`cdet_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


DROP TABLE IF EXISTS `mis_collection_revenue`;
CREATE TABLE `mis_collection_revenue` (
  `rev_id` bigint NOT NULL,
  `rev_coll_id` bigint NOT NULL,
  `rev_type` smallint NOT NULL,
  `rev_group_id` smallint NOT NULL,
  `rev_bill_id` bigint NOT NULL,
  `rev_vhl_id` bigint NOT NULL,
  `rev_remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `rev_revenue` decimal(9,3) DEFAULT NULL,
  `u_created` bigint DEFAULT NULL,
  `u_modified` bigint DEFAULT NULL,
  `u_deleted` bigint DEFAULT NULL,
  `t_created` timestamp NULL DEFAULT NULL,
  `t_modified` timestamp NULL DEFAULT NULL,
  `t_deleted` timestamp NULL DEFAULT NULL,
  `deleted` smallint NOT NULL DEFAULT '0',
  PRIMARY KEY (`rev_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


DROP TABLE IF EXISTS `mis_contacts`;
CREATE TABLE `mis_contacts` (
  `con_id` bigint NOT NULL,
  `con_type` smallint NOT NULL,
  `con_ref_type` smallint NOT NULL,
  `con_ref_id` bigint NOT NULL,
  `con_name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `con_house` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `con_street1` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `con_street2` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `con_place` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `con_locality` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `con_region` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `con_country` smallint DEFAULT NULL,
  `con_zip_code` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `con_phone` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `con_mobile` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `u_created` bigint DEFAULT NULL,
  `u_modified` bigint DEFAULT NULL,
  `u_deleted` bigint DEFAULT NULL,
  `t_created` datetime DEFAULT NULL,
  `t_modified` datetime DEFAULT NULL,
  `t_deleted` datetime DEFAULT NULL,
  `deleted` smallint NOT NULL DEFAULT '0',
  `is_synched` smallint DEFAULT '1',
  PRIMARY KEY (`con_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


DROP TABLE IF EXISTS `mis_customer`;
CREATE TABLE `mis_customer` (
  `cust_id` bigint NOT NULL,
  `cust_code` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `cust_name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `cust_remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `cust_status` bigint NOT NULL DEFAULT '1',
  `cust_pay_mode` bigint DEFAULT NULL,
  `u_created` bigint DEFAULT NULL,
  `u_modified` bigint DEFAULT NULL,
  `u_deleted` bigint DEFAULT NULL,
  `t_created` datetime DEFAULT NULL,
  `t_modified` datetime DEFAULT NULL,
  `t_deleted` datetime DEFAULT NULL,
  `deleted` smallint NOT NULL DEFAULT '0',
  `is_synched` smallint DEFAULT '1',
  PRIMARY KEY (`cust_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


DROP TABLE IF EXISTS `mis_documents`;
CREATE TABLE `mis_documents` (
  `doc_id` bigint NOT NULL,
  `doc_type` smallint NOT NULL,
  `doc_ref_type` smallint NOT NULL,
  `doc_ref_id` bigint NOT NULL,
  `doc_no` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `doc_desc` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `doc_remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `doc_issue_auth` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `doc_apply_date` date DEFAULT NULL,
  `doc_issue_date` date DEFAULT NULL,
  `doc_expiry_date` date DEFAULT NULL,
  `doc_alert_days` smallint DEFAULT '0',
  `u_created` bigint DEFAULT NULL,
  `u_modified` bigint DEFAULT NULL,
  `u_deleted` bigint DEFAULT NULL,
  `t_created` datetime DEFAULT NULL,
  `t_modified` datetime DEFAULT NULL,
  `t_deleted` datetime DEFAULT NULL,
  `deleted` smallint NOT NULL DEFAULT '0',
  `agr_tenant` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `agr_mobile` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `agr_tele` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `agr_idno` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `agr_rent` decimal(9,2) DEFAULT '0.00',
  `agr_tax` decimal(9,2) DEFAULT '0.00',
  `agr_expat` smallint DEFAULT NULL,
  `agr_crno` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `agr_paydet` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `agr_comp` smallint DEFAULT NULL,
  `agr_amount` decimal(13,3) DEFAULT NULL,
  `agr_tnt_id` bigint DEFAULT NULL,
  `doc_remainder` smallint DEFAULT NULL,
  `doc_dyn_no` bigint DEFAULT NULL,
  `doc_dyn_label` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `doc_dyn_ver` smallint DEFAULT NULL,
  `is_synched` smallint DEFAULT '1',
  PRIMARY KEY (`doc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


DROP TABLE IF EXISTS `mis_emp_contract`;
CREATE TABLE `mis_emp_contract` (
  `emc_id` bigint NOT NULL,
  `emc_emp_id` bigint NOT NULL,
  `emc_vhl_id` bigint NOT NULL,
  `emc_status` smallint NOT NULL DEFAULT '1',
  `emc_cust_id` bigint NOT NULL,
  `emc_project` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `emc_location` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `emc_note` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `emc_date_start` date NOT NULL,
  `emc_date_end` date DEFAULT NULL,
  `u_created` bigint DEFAULT NULL,
  `u_modified` bigint DEFAULT NULL,
  `u_deleted` bigint DEFAULT NULL,
  `t_created` datetime DEFAULT NULL,
  `t_modified` datetime DEFAULT NULL,
  `t_deleted` datetime DEFAULT NULL,
  `deleted` smallint NOT NULL DEFAULT '0',
  `emc_note2` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `is_synched` smallint DEFAULT '1',
  PRIMARY KEY (`emc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


DROP TABLE IF EXISTS `mis_employee`;
CREATE TABLE `mis_employee` (
  `emp_id` bigint NOT NULL,
  `emp_no` bigint NOT NULL,
  `emp_fileno` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `emp_mobileno` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `emp_fname` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `emp_mname` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `emp_lname` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `emp_nationality` smallint DEFAULT NULL,
  `emp_dob` date DEFAULT NULL,
  `emp_doj` date DEFAULT NULL,
  `emp_comp_dept` smallint NOT NULL,
  `emp_desig` smallint NOT NULL,
  `emp_status` smallint DEFAULT '1',
  `emp_bank` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `emp_branch` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `emp_accountno` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `u_created` bigint DEFAULT NULL,
  `u_modified` bigint DEFAULT NULL,
  `u_deleted` bigint DEFAULT NULL,
  `t_created` datetime DEFAULT NULL,
  `t_modified` datetime DEFAULT NULL,
  `t_deleted` datetime DEFAULT NULL,
  `deleted` smallint NOT NULL DEFAULT '0',
  `emp_nativeno` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `emp_bank_id` smallint DEFAULT NULL,
  `emp_reg_mulkia` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `emp_reg_chassis` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `emp_reg_refno` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `emp_reg_remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `is_synched` smallint DEFAULT '1',
  PRIMARY KEY (`emp_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


DROP TABLE IF EXISTS `mis_employee_pay`;
CREATE TABLE `mis_employee_pay` (
  `pay_id` bigint NOT NULL,
  `pay_emp_id` bigint DEFAULT NULL,
  `pay_type` smallint NOT NULL DEFAULT '0',
  `pay_basic` decimal(13,3) DEFAULT '0.000',
  `pay_da` decimal(13,3) DEFAULT '0.000',
  `pay_hra` decimal(13,3) DEFAULT '0.000',
  `pay_ta` decimal(13,3) DEFAULT '0.000',
  `pay_allw1` decimal(13,3) DEFAULT '0.000',
  `pay_allw2` decimal(13,3) DEFAULT '0.000',
  `pay_allw3` decimal(13,3) DEFAULT '0.000',
  `pay_total` decimal(13,3) DEFAULT '0.000',
  `pay_wef` date DEFAULT NULL,
  `pay_dor` date DEFAULT NULL,
  `pay_remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `u_created` bigint DEFAULT NULL,
  `u_modified` bigint DEFAULT NULL,
  `u_deleted` bigint DEFAULT NULL,
  `t_created` datetime DEFAULT NULL,
  `t_modified` datetime DEFAULT NULL,
  `t_deleted` datetime DEFAULT NULL,
  `deleted` smallint NOT NULL DEFAULT '0',
  `is_synched` smallint DEFAULT '1',
  PRIMARY KEY (`pay_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


DROP TABLE IF EXISTS `mis_employee_status`;
CREATE TABLE `mis_employee_status` (
  `sts_id` bigint NOT NULL,
  `sts_type` smallint NOT NULL,
  `sts_emp_id` bigint NOT NULL,
  `sts_remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `sts_apply_date` date DEFAULT NULL,
  `sts_approval_date` date DEFAULT NULL,
  `sts_start_date` date DEFAULT NULL,
  `sts_end_date` date DEFAULT NULL,
  `u_created` bigint DEFAULT NULL,
  `u_modified` bigint DEFAULT NULL,
  `u_deleted` bigint DEFAULT NULL,
  `t_created` datetime DEFAULT NULL,
  `t_modified` datetime DEFAULT NULL,
  `t_deleted` datetime DEFAULT NULL,
  `deleted` smallint NOT NULL DEFAULT '0',
  `is_synched` smallint DEFAULT '1',
  `sts_notif_120` smallint DEFAULT '0',
  `sts_notif_170` smallint DEFAULT '0',
  PRIMARY KEY (`sts_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


DROP TABLE IF EXISTS `mis_expense`;
CREATE TABLE `mis_expense` (
  `exp_id` bigint NOT NULL,
  `exp_vendor` bigint NOT NULL,
  `exp_company` bigint NOT NULL,
  `exp_mainh` smallint NOT NULL,
  `exp_mainh_ref` bigint DEFAULT NULL,
  `exp_pcat` bigint NOT NULL,
  `exp_scat` bigint NOT NULL,
  `exp_ccat` bigint NOT NULL,
  `exp_details` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `exp_amount` decimal(13,3) NOT NULL,
  `exp_pay_mode` smallint NOT NULL,
  `exp_remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `exp_paydate` date DEFAULT NULL,
  `exp_refno` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `u_created` bigint DEFAULT NULL,
  `u_modified` bigint DEFAULT NULL,
  `u_deleted` bigint DEFAULT NULL,
  `t_created` datetime DEFAULT NULL,
  `t_modified` datetime DEFAULT NULL,
  `t_deleted` datetime DEFAULT NULL,
  `deleted` smallint NOT NULL DEFAULT '0',
  `exp_file_no` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `exp_app_status` smallint DEFAULT NULL,
  `exp_app_date` datetime DEFAULT NULL,
  `exp_app_note` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `exp_billdt` date DEFAULT NULL,
  `exp_paydays` smallint DEFAULT NULL,
  `exp_pstatus` bigint DEFAULT NULL,
  `exp_credit_amt` decimal(13,3) DEFAULT NULL,
  `exp_oribill_amt` decimal(13,3) DEFAULT NULL,
  `exp_cash_flow` bigint DEFAULT NULL,
  `exp_update_status` smallint DEFAULT NULL,
  `exp_export` bigint DEFAULT NULL,
  `exp_vat_amt` decimal(13,3) DEFAULT NULL,
  `exp_vat_option` smallint DEFAULT '0',
  `exp_novat_amt` decimal(13,3) DEFAULT NULL,
  `is_synched` smallint DEFAULT '1',
  PRIMARY KEY (`exp_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


DROP TABLE IF EXISTS `mis_expense_href`;
CREATE TABLE `mis_expense_href` (
  `eref_id` bigint NOT NULL,
  `eref_exp_id` bigint NOT NULL,
  `eref_main_head` smallint NOT NULL,
  `eref_main_head_ref` bigint NOT NULL,
  `eref_amount` decimal(13,3) NOT NULL,
  `u_created` bigint DEFAULT NULL,
  `u_modified` bigint DEFAULT NULL,
  `u_deleted` bigint DEFAULT NULL,
  `t_created` datetime DEFAULT NULL,
  `t_modified` datetime DEFAULT NULL,
  `t_deleted` datetime DEFAULT NULL,
  `deleted` smallint NOT NULL DEFAULT '0',
  `eref_status` smallint NOT NULL DEFAULT '1',
  `is_synched` smallint DEFAULT '1',
  PRIMARY KEY (`eref_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


DROP TABLE IF EXISTS `mis_expense_update`;
CREATE TABLE `mis_expense_update` (
  `eup_id` bigint NOT NULL,
  `eup_exp_id` bigint DEFAULT NULL,
  `eup_type` smallint NOT NULL,
  `eup_date` date NOT NULL,
  `eup_exp_topay` decimal(13,3) NOT NULL,
  `eup_exp_adjust` decimal(13,3) DEFAULT NULL,
  `eup_exp_credit` decimal(13,3) DEFAULT NULL,
  `eup_app_status` smallint DEFAULT NULL,
  `eup_app_date` date DEFAULT NULL,
  `eup_app_by` bigint DEFAULT NULL,
  `u_created` bigint DEFAULT NULL,
  `u_modified` bigint DEFAULT NULL,
  `u_deleted` bigint DEFAULT NULL,
  `t_created` datetime DEFAULT NULL,
  `t_modified` datetime DEFAULT NULL,
  `t_deleted` datetime DEFAULT NULL,
  `deleted` smallint NOT NULL DEFAULT '0',
  `is_synched` smallint DEFAULT '1',
  PRIMARY KEY (`eup_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


DROP TABLE IF EXISTS `mis_item`;
CREATE TABLE `mis_item` (
  `item_id` bigint NOT NULL,
  `item_code` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `item_name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `item_remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `item_status` bigint NOT NULL DEFAULT '1',
  `item_price` decimal(13,3) DEFAULT NULL,
  `u_created` bigint DEFAULT NULL,
  `u_modified` bigint DEFAULT NULL,
  `u_deleted` bigint DEFAULT NULL,
  `t_created` datetime DEFAULT NULL,
  `t_modified` datetime DEFAULT NULL,
  `t_deleted` datetime DEFAULT NULL,
  `deleted` smallint NOT NULL DEFAULT '0',
  `item_unit` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `item_type` smallint DEFAULT '1',
  `item_vehicle` bigint DEFAULT NULL,
  `is_synched` smallint DEFAULT '1',
  PRIMARY KEY (`item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


DROP TABLE IF EXISTS `mis_legal_case`;
CREATE TABLE `mis_legal_case` (
  `lcas_id` bigint NOT NULL,
  `lcas_type` smallint DEFAULT '1',
  `lcas_party` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `lcas_phone_no` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `lcas_office` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `lcas_lawer` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `lcas_email` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `lcas_date` date NOT NULL,
  `lcas_emp` bigint DEFAULT NULL,
  `lcas_case` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `lcas_sts` smallint DEFAULT '1',
  `u_created` bigint DEFAULT NULL,
  `u_modified` bigint DEFAULT NULL,
  `u_deleted` bigint DEFAULT NULL,
  `t_created` timestamp NULL DEFAULT NULL,
  `t_modified` timestamp NULL DEFAULT NULL,
  `t_deleted` timestamp NULL DEFAULT NULL,
  `deleted` smallint NOT NULL DEFAULT '0',
  `lcas_no` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `lcas_ref` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `lcas_company` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `lcas_cr` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `lcas_ref_comp` smallint DEFAULT NULL,
  PRIMARY KEY (`lcas_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


DROP TABLE IF EXISTS `mis_legal_case_follow`;
CREATE TABLE `mis_legal_case_follow` (
  `lcflo_id` bigint NOT NULL,
  `lcflo_lcas_id` bigint DEFAULT NULL,
  `lcflo_update` text,
  `lcflo_date` date NOT NULL,
  `lcflo_emp` bigint DEFAULT NULL,
  `lcflo_sts` smallint DEFAULT '1',
  `u_created` bigint DEFAULT NULL,
  `u_modified` bigint DEFAULT NULL,
  `u_deleted` bigint DEFAULT NULL,
  `t_created` timestamp NULL DEFAULT NULL,
  `t_modified` timestamp NULL DEFAULT NULL,
  `t_deleted` timestamp NULL DEFAULT NULL,
  `deleted` smallint NOT NULL DEFAULT '0',
  PRIMARY KEY (`lcflo_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `mis_notification`;
CREATE TABLE `mis_notification` (
  `notif_id` bigint NOT NULL,
  `notif_month` date NOT NULL,
  `notif_email` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `notif_content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `notif_status` smallint DEFAULT NULL,
  `u_created` bigint DEFAULT NULL,
  `u_modified` bigint DEFAULT NULL,
  `u_deleted` bigint DEFAULT NULL,
  `t_created` datetime DEFAULT NULL,
  `t_modified` datetime DEFAULT NULL,
  `t_deleted` datetime DEFAULT NULL,
  `deleted` smallint DEFAULT '0',
  `is_synched` smallint DEFAULT '1',
  PRIMARY KEY (`notif_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


DROP TABLE IF EXISTS `mis_payment`;
CREATE TABLE `mis_payment` (
  `pay_id` bigint NOT NULL,
  `pay_vendor` bigint NOT NULL,
  `pay_amount` decimal(13,3) NOT NULL,
  `pay_pay_mode` smallint NOT NULL DEFAULT '1',
  `pay_chqno` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `pay_remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `pay_paydate` date NOT NULL,
  `pay_refno` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `u_created` bigint DEFAULT NULL,
  `u_modified` bigint DEFAULT NULL,
  `u_deleted` bigint DEFAULT NULL,
  `t_created` datetime DEFAULT NULL,
  `t_modified` datetime DEFAULT NULL,
  `t_deleted` datetime DEFAULT NULL,
  `deleted` smallint NOT NULL DEFAULT '0',
  `pay_file_no` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `pay_app_date` date DEFAULT NULL,
  `pay_app_by` bigint DEFAULT NULL,
  `pay_app_note` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `pay_app_status` smallint DEFAULT '0',
  `pay_pay_status` smallint DEFAULT NULL,
  `pay_pay_note` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `pay_pay_date` date DEFAULT NULL,
  `pay_pay_app_date` timestamp NULL DEFAULT NULL,
  `pay_cash_flow` bigint DEFAULT NULL,
  `is_synched` smallint DEFAULT '1',
  PRIMARY KEY (`pay_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


DROP TABLE IF EXISTS `mis_payment_det`;
CREATE TABLE `mis_payment_det` (
  `pdet_id` bigint NOT NULL,
  `pdet_pay_id` bigint DEFAULT NULL,
  `pdet_exp_id` bigint DEFAULT NULL,
  `pdet_amt_topay` decimal(13,3) NOT NULL,
  `pdet_amt_paid` decimal(13,3) NOT NULL,
  `pdet_amt_dis` decimal(13,3) DEFAULT NULL,
  `pdet_amt_bal` decimal(13,3) DEFAULT NULL,
  `pdet_status` smallint DEFAULT '1',
  `u_created` bigint DEFAULT NULL,
  `u_modified` bigint DEFAULT NULL,
  `u_deleted` bigint DEFAULT NULL,
  `t_created` datetime DEFAULT NULL,
  `t_modified` datetime DEFAULT NULL,
  `t_deleted` datetime DEFAULT NULL,
  `deleted` smallint NOT NULL DEFAULT '0',
  `is_synched` smallint DEFAULT '1',
  PRIMARY KEY (`pdet_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


DROP TABLE IF EXISTS `mis_property`;
CREATE TABLE `mis_property` (
  `prop_id` bigint NOT NULL,
  `prop_no` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `prop_name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `prop_fileno` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `prop_building` smallint NOT NULL,
  `prop_responsible` bigint DEFAULT NULL,
  `prop_remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `u_created` bigint DEFAULT NULL,
  `u_modified` bigint DEFAULT NULL,
  `u_deleted` bigint DEFAULT NULL,
  `t_created` datetime DEFAULT NULL,
  `t_modified` datetime DEFAULT NULL,
  `t_deleted` datetime DEFAULT NULL,
  `deleted` smallint NOT NULL DEFAULT '0',
  `prop_cat` smallint DEFAULT NULL,
  `prop_type` smallint DEFAULT NULL,
  `prop_level` smallint DEFAULT NULL,
  `prop_elec_meter` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `prop_water` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `prop_building_type` smallint DEFAULT NULL,
  `prop_status` bigint DEFAULT '1',
  `prop_elec_account` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `prop_elec_recharge` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `prop_account` bigint DEFAULT NULL,
  `is_synched` smallint DEFAULT '1',
  PRIMARY KEY (`prop_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


DROP TABLE IF EXISTS `mis_property_payoption`;
CREATE TABLE `mis_property_payoption` (
  `popt_id` bigint NOT NULL,
  `popt_prop_id` bigint DEFAULT NULL,
  `popt_doc_id` bigint DEFAULT NULL,
  `popt_type` smallint NOT NULL,
  `popt_date` date NOT NULL,
  `popt_amount` decimal(13,3) DEFAULT NULL,
  `popt_bank` smallint DEFAULT NULL,
  `popt_chqno` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `popt_status` smallint DEFAULT '1',
  `popt_status_date` date DEFAULT NULL,
  `u_created` bigint DEFAULT NULL,
  `u_modified` bigint DEFAULT NULL,
  `u_deleted` bigint DEFAULT NULL,
  `t_created` datetime DEFAULT NULL,
  `t_modified` datetime DEFAULT NULL,
  `t_deleted` datetime DEFAULT NULL,
  `deleted` smallint NOT NULL DEFAULT '0',
  `is_synched` smallint DEFAULT '1',
  PRIMARY KEY (`popt_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


DROP TABLE IF EXISTS `mis_property_service`;
CREATE TABLE `mis_property_service` (
  `psvs_id` bigint NOT NULL,
  `psvs_prop_id` bigint DEFAULT NULL,
  `psvs_type` smallint DEFAULT '1',
  `psvs_complaint_no` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `psvs_date` date NOT NULL,
  `psvs_srv_date` date NOT NULL,
  `psvs_emp` bigint DEFAULT NULL,
  `psvs_time_in` time DEFAULT NULL,
  `psvs_time_out` time DEFAULT NULL,
  `psvs_service_json` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `psvs_parts_json` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `psvs_signed` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `psvs_amt_mat` decimal(9,3) DEFAULT NULL,
  `psvs_amt_lab` decimal(9,3) DEFAULT NULL,
  `psvs_amt_tot` decimal(9,3) DEFAULT NULL,
  `psvs_signed_phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `psvs_feedback` smallint DEFAULT NULL,
  `psvs_remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `u_created` bigint DEFAULT NULL,
  `u_modified` bigint DEFAULT NULL,
  `u_deleted` bigint DEFAULT NULL,
  `t_created` datetime DEFAULT NULL,
  `t_modified` datetime DEFAULT NULL,
  `t_deleted` datetime DEFAULT NULL,
  `deleted` smallint NOT NULL DEFAULT '0',
  `is_synched` smallint DEFAULT '1',
  PRIMARY KEY (`psvs_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


DROP TABLE IF EXISTS `mis_property_status`;
CREATE TABLE `mis_property_status` (
  `psts_id` bigint NOT NULL,
  `psts_type` smallint DEFAULT '1',
  `psts_prop_id` bigint DEFAULT NULL,
  `psts_remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `psts_status_date` date NOT NULL,
  `u_created` bigint DEFAULT NULL,
  `u_modified` bigint DEFAULT NULL,
  `u_deleted` bigint DEFAULT NULL,
  `t_created` datetime DEFAULT NULL,
  `t_modified` datetime DEFAULT NULL,
  `t_deleted` datetime DEFAULT NULL,
  `deleted` smallint NOT NULL DEFAULT '0',
  `psts_attach_prop` bigint DEFAULT NULL,
  `is_synched` smallint DEFAULT '1',
  PRIMARY KEY (`psts_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


DROP TABLE IF EXISTS `mis_salary`;
CREATE TABLE `mis_salary` (
  `sal_id` bigint NOT NULL,
  `sal_period` smallint NOT NULL,
  `sal_total` decimal(13,3) DEFAULT NULL,
  `sal_addition` decimal(13,3) DEFAULT NULL,
  `sal_deduction` decimal(13,3) DEFAULT NULL,
  `sal_net` decimal(13,3) DEFAULT NULL,
  `sal_remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `sal_paydate` date DEFAULT NULL,
  `u_created` bigint DEFAULT NULL,
  `u_modified` bigint DEFAULT NULL,
  `u_deleted` bigint DEFAULT NULL,
  `t_created` datetime DEFAULT NULL,
  `t_modified` datetime DEFAULT NULL,
  `t_deleted` datetime DEFAULT NULL,
  `deleted` smallint NOT NULL DEFAULT '0',
  `sal_status` smallint DEFAULT '1',
  `sal_empcount` smallint DEFAULT '0',
  `is_synched` smallint DEFAULT '1',
  PRIMARY KEY (`sal_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


DROP TABLE IF EXISTS `mis_salary_det`;
CREATE TABLE `mis_salary_det` (
  `sdet_id` bigint NOT NULL,
  `sdet_sal_id` bigint DEFAULT NULL,
  `sdet_emp_id` bigint DEFAULT NULL,
  `sdet_group` smallint NOT NULL,
  `sdet_amt_total` decimal(13,3) DEFAULT NULL,
  `sdet_amt_deduct` decimal(13,3) DEFAULT NULL,
  `sdet_amt_addition` decimal(13,3) DEFAULT NULL,
  `sdet_amt_net` decimal(13,3) DEFAULT NULL,
  `sdet_remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `sdet_status` smallint DEFAULT '1',
  `u_created` bigint DEFAULT NULL,
  `u_modified` bigint DEFAULT NULL,
  `u_deleted` bigint DEFAULT NULL,
  `t_created` datetime DEFAULT NULL,
  `t_modified` datetime DEFAULT NULL,
  `t_deleted` datetime DEFAULT NULL,
  `deleted` smallint NOT NULL DEFAULT '0',
  `sdet_category` smallint DEFAULT NULL,
  `is_synched` smallint DEFAULT '1',
  PRIMARY KEY (`sdet_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


DROP TABLE IF EXISTS `mis_tenants`;
CREATE TABLE `mis_tenants` (
  `tnt_id` bigint NOT NULL,
  `tnt_full_name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `tnt_comp_name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `tnt_phone` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `tnt_tele` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `tnt_id_no` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `tnt_crno` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `tnt_expat` smallint DEFAULT NULL,
  `tnt_agr_type` smallint DEFAULT NULL,
  `u_created` bigint DEFAULT NULL,
  `u_modified` bigint DEFAULT NULL,
  `u_deleted` bigint DEFAULT NULL,
  `t_created` datetime DEFAULT NULL,
  `t_modified` datetime DEFAULT NULL,
  `t_deleted` datetime DEFAULT NULL,
  `deleted` smallint NOT NULL DEFAULT '0',
  `tnt_doc_id` bigint DEFAULT NULL,
  `is_synched` smallint DEFAULT '1',
  `tnt_email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `tnt_post` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`tnt_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin COMMENT='mis_tenants table';


DROP TABLE IF EXISTS `mis_tickets`;
CREATE TABLE `mis_tickets` (
  `tkt_id` bigint NOT NULL,
  `tkt_company` bigint NOT NULL,
  `tkt_reported` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `tkt_cat` smallint NOT NULL,
  `tkt_mob1` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `tkt_mob2` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `tkt_vtime_srt` time DEFAULT NULL,
  `tkt_vtime_end` time DEFAULT NULL,
  `tkt_assign` bigint DEFAULT NULL,
  `tkt_mainhead` smallint NOT NULL,
  `tkt_dttime_strt` timestamp NULL DEFAULT NULL,
  `tkt_dttime_end` timestamp NULL DEFAULT NULL,
  `tkt_priority` smallint NOT NULL,
  `tkt_budjet` decimal(13,3) DEFAULT NULL,
  `tkt_status` smallint DEFAULT NULL,
  `tkt_details` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `u_created` bigint DEFAULT NULL,
  `u_modified` bigint DEFAULT NULL,
  `u_deleted` bigint DEFAULT NULL,
  `t_created` datetime DEFAULT NULL,
  `t_modified` datetime DEFAULT NULL,
  `t_deleted` datetime DEFAULT NULL,
  `deleted` smallint NOT NULL DEFAULT '0',
  `is_synched` smallint DEFAULT '1',
  PRIMARY KEY (`tkt_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


DROP TABLE IF EXISTS `mis_tickets_actions`;
CREATE TABLE `mis_tickets_actions` (
  `act_id` bigint NOT NULL,
  `act_ticket_id` smallint NOT NULL,
  `act_by` bigint NOT NULL,
  `act_remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `act_steps` bigint DEFAULT NULL,
  `act_status` smallint NOT NULL,
  `act_dttime` timestamp NULL DEFAULT NULL,
  `act_escalate` bigint DEFAULT NULL,
  `u_created` bigint DEFAULT NULL,
  `u_modified` bigint DEFAULT NULL,
  `u_deleted` bigint DEFAULT NULL,
  `t_created` datetime DEFAULT NULL,
  `t_modified` datetime DEFAULT NULL,
  `t_deleted` datetime DEFAULT NULL,
  `deleted` smallint NOT NULL DEFAULT '0',
  `is_synched` smallint DEFAULT '1',
  PRIMARY KEY (`act_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


DROP TABLE IF EXISTS `mis_tickets_cat`;
CREATE TABLE `mis_tickets_cat` (
  `tcat_id` bigint NOT NULL,
  `tcat_type` smallint DEFAULT '1',
  `tcat_name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `tcat_remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `u_created` bigint DEFAULT NULL,
  `u_modified` bigint DEFAULT NULL,
  `u_deleted` bigint DEFAULT NULL,
  `t_created` datetime DEFAULT NULL,
  `t_modified` datetime DEFAULT NULL,
  `t_deleted` datetime DEFAULT NULL,
  `deleted` smallint NOT NULL DEFAULT '0',
  `is_synched` smallint DEFAULT '1',
  PRIMARY KEY (`tcat_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


DROP TABLE IF EXISTS `mis_tickets_href`;
CREATE TABLE `mis_tickets_href` (
  `tref_id` bigint NOT NULL,
  `tref_tkt_id` bigint NOT NULL,
  `tref_main_head` smallint NOT NULL,
  `tref_main_head_ref` bigint NOT NULL,
  `tref_note` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `u_created` bigint DEFAULT NULL,
  `u_modified` bigint DEFAULT NULL,
  `u_deleted` bigint DEFAULT NULL,
  `t_created` datetime DEFAULT NULL,
  `t_modified` datetime DEFAULT NULL,
  `t_deleted` datetime DEFAULT NULL,
  `deleted` smallint NOT NULL DEFAULT '0',
  `is_synched` smallint DEFAULT '1',
  PRIMARY KEY (`tref_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


DROP TABLE IF EXISTS `mis_tickets_steps`;
CREATE TABLE `mis_tickets_steps` (
  `stp_id` bigint NOT NULL,
  `stp_ticket_id` smallint NOT NULL,
  `stp_by` bigint NOT NULL,
  `stp_steps` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `stp_dttime` timestamp NULL DEFAULT NULL,
  `u_created` bigint DEFAULT NULL,
  `u_modified` bigint DEFAULT NULL,
  `u_deleted` bigint DEFAULT NULL,
  `t_created` datetime DEFAULT NULL,
  `t_modified` datetime DEFAULT NULL,
  `t_deleted` datetime DEFAULT NULL,
  `deleted` smallint NOT NULL DEFAULT '0',
  `is_synched` smallint DEFAULT '1',
  PRIMARY KEY (`stp_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


DROP TABLE IF EXISTS `mis_vehicle`;
CREATE TABLE `mis_vehicle` (
  `vhl_id` bigint NOT NULL,
  `vhl_no` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `vhl_fileno` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `vhl_type` smallint NOT NULL,
  `vhl_model` bigint NOT NULL,
  `vhl_company` smallint NOT NULL,
  `vhl_responsible` bigint DEFAULT NULL,
  `vhl_remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `u_created` bigint DEFAULT NULL,
  `u_modified` bigint DEFAULT NULL,
  `u_deleted` bigint DEFAULT NULL,
  `t_created` datetime DEFAULT NULL,
  `t_modified` datetime DEFAULT NULL,
  `t_deleted` datetime DEFAULT NULL,
  `deleted` smallint NOT NULL DEFAULT '0',
  `vhl_comm_status` smallint NOT NULL DEFAULT '1',
  `vhl_rate_hour` decimal(13,3) DEFAULT NULL,
  `vhl_rate_day` decimal(13,3) DEFAULT NULL,
  `vhl_rate_month` decimal(13,3) DEFAULT NULL,
  `vhl_man` smallint DEFAULT NULL,
  `vhl_employed` bigint DEFAULT NULL,
  `vhl_vendor` bigint DEFAULT NULL,
  `vhl_site` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `vhl_company_old` bigint DEFAULT NULL,
  `vhl_status` smallint DEFAULT '1',
  `is_synched` smallint DEFAULT '1',
  PRIMARY KEY (`vhl_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


DROP TABLE IF EXISTS `mis_vehicle_man`;
CREATE TABLE `mis_vehicle_man` (
  `vman_id` bigint NOT NULL,
  `vman_name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `u_created` bigint DEFAULT NULL,
  `u_modified` bigint DEFAULT NULL,
  `u_deleted` bigint DEFAULT NULL,
  `t_created` datetime DEFAULT NULL,
  `t_modified` datetime DEFAULT NULL,
  `t_deleted` datetime DEFAULT NULL,
  `deleted` smallint NOT NULL DEFAULT '0',
  `vman_code` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `is_synched` smallint DEFAULT '1',
  PRIMARY KEY (`vman_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


DROP TABLE IF EXISTS `mis_vehicle_type`;
CREATE TABLE `mis_vehicle_type` (
  `type_id` bigint NOT NULL,
  `type_name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `u_created` bigint DEFAULT NULL,
  `u_modified` bigint DEFAULT NULL,
  `u_deleted` bigint DEFAULT NULL,
  `t_created` datetime DEFAULT NULL,
  `t_modified` datetime DEFAULT NULL,
  `t_deleted` datetime DEFAULT NULL,
  `deleted` smallint NOT NULL DEFAULT '0',
  `type_code` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `is_synched` smallint DEFAULT '1',
  PRIMARY KEY (`type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


DROP TABLE IF EXISTS `mis_vendor`;
CREATE TABLE `mis_vendor` (
  `ven_id` bigint NOT NULL,
  `ven_code` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `ven_name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `ven_remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `ven_status` smallint NOT NULL DEFAULT '1',
  `ven_pay_mode` smallint DEFAULT NULL,
  `u_created` bigint DEFAULT NULL,
  `u_modified` bigint DEFAULT NULL,
  `u_deleted` bigint DEFAULT NULL,
  `t_created` datetime DEFAULT NULL,
  `t_modified` datetime DEFAULT NULL,
  `t_deleted` datetime DEFAULT NULL,
  `deleted` smallint NOT NULL DEFAULT '0',
  `ven_disp_name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `ven_vat_no` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `ven_type` smallint NOT NULL DEFAULT '1',
  `is_synched` smallint DEFAULT '1',
  PRIMARY KEY (`ven_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


DROP TABLE IF EXISTS `mis_vhl_service`;
CREATE TABLE `mis_vhl_service` (
  `srv_id` bigint NOT NULL,
  `srv_vhl_id` bigint NOT NULL,
  `srv_date_start` date NOT NULL,
  `srv_location` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `srv_reading` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `srv_note` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `srv_type` smallint DEFAULT NULL COMMENT 'relevant only when srv_category = 1',
  `srv_nxt_type` smallint DEFAULT NULL COMMENT 'relevant only when srv_category = 1',
  `srv_done_by` bigint DEFAULT NULL,
  `srv_reading_next` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `srv_date_next` date DEFAULT NULL,
  `srv_wash` smallint DEFAULT NULL,
  `srv_greese` smallint DEFAULT NULL,
  `u_created` bigint DEFAULT NULL,
  `u_modified` bigint DEFAULT NULL,
  `u_deleted` bigint DEFAULT NULL,
  `t_created` datetime DEFAULT NULL,
  `t_modified` datetime DEFAULT NULL,
  `t_deleted` datetime DEFAULT NULL,
  `deleted` smallint NOT NULL DEFAULT '0',
  `srv_labour` decimal(9,3) DEFAULT NULL,
  `is_synched` smallint DEFAULT '1',
  `srv_working_time` decimal(5,2) DEFAULT NULL,
  `srv_reading_type` smallint DEFAULT NULL,
  `srv_reading_next_type` smallint DEFAULT NULL,
  `srv_category` smallint DEFAULT NULL COMMENT '1 => Service, 2 => Accident',
  PRIMARY KEY (`srv_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


DROP TABLE IF EXISTS `mis_vhl_srv_det`;
CREATE TABLE `mis_vhl_srv_det` (
  `sdt_id` bigint NOT NULL,
  `sdt_srv_id` bigint NOT NULL,
  `sdt_item` bigint NOT NULL,
  `sdt_qty` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `sdt_done_by` bigint NOT NULL,
  `sdt_note` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `u_created` bigint DEFAULT NULL,
  `u_modified` bigint DEFAULT NULL,
  `u_deleted` bigint DEFAULT NULL,
  `t_created` datetime DEFAULT NULL,
  `t_modified` datetime DEFAULT NULL,
  `t_deleted` datetime DEFAULT NULL,
  `deleted` smallint NOT NULL DEFAULT '0',
  `sdt_unit` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `sdt_price` decimal(9,3) DEFAULT NULL,
  `sdt_billid` bigint DEFAULT NULL,
  `is_synched` smallint DEFAULT '1',
  PRIMARY KEY (`sdt_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


-- 2025-01-18 04:36:44
